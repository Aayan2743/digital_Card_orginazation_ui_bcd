//src/pages/organizations/EditOrganization.jsx
export default function EditOrganization() {
  return <p> Edit Orgization</p>;
}
